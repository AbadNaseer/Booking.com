const express = require('express');
const bookController = require('../controllers/bookControllers');

const router = express.Router();

router.get('/books', bookController.getAllBooks);
router.get('/books/:id', bookController.getBookDetails);
router.post('/books', bookController.addNewBook);

module.exports = router;
