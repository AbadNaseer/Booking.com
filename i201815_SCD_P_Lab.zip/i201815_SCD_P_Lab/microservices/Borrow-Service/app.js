const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');

const app = express();
const port = 3002;

mongoose.connect('mongodb://localhost:27017/borrowingdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(express.json());

// Book and User services URLs
const bookServiceUrl = 'http://localhost:3000/api/books';
const userServiceUrl = 'http://localhost:3001/api/users';

// Borrowing Model
const Borrowing = mongoose.model('Borrowing', {
  userId: { type: String, required: true },
  bookId: { type: String, required: true },
  borrowedDate: { type: Date, default: Date.now },
  returnedDate: { type: Date, default: null },
});

// Borrow a book
app.post('/api/borrow', async (req, res) => {
  const { userId, bookId } = req.body;

  try {
    // Check if the user exists
    const userResponse = await axios.get(`${userServiceUrl}/users/${userId}`);
    if (userResponse.status !== 200) {
      return res.status(userResponse.status).json({ error: 'User not found' });
    }

    // Check if the book exists and is available
    const bookResponse = await axios.get(`${bookServiceUrl}/books/${bookId}`);
    if (bookResponse.status !== 200 || !bookResponse.data.available) {
      return res.status(bookResponse.status).json({ error: 'Book not available' });
    }

    // Create a borrowing record
    const newBorrowing = new Borrowing({ userId, bookId });
    await newBorrowing.save();

    // Update book availability
    await axios.put(`${bookServiceUrl}/books/${bookId}`, { available: false });

    res.status(201).json(newBorrowing);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Return a book
app.post('/api/return', async (req, res) => {
  const { userId, bookId } = req.body;

  try {
    // Find the borrowing record
    const borrowing = await Borrowing.findOne({ userId, bookId, returnedDate: null });
    if (!borrowing) {
      return res.status(404).json({ error: 'Borrowing record not found' });
    }

    // Update borrowing record with return date
    borrowing.returnedDate = Date.now();
    await borrowing.save();

    // Update book availability
    await axios.put(`${bookServiceUrl}/books/${bookId}`, { available: true });

    res.json(borrowing);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get user's borrowed books
app.get('/api/borrowed-books/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    // Find all borrowing records for the user
    const borrowings = await Borrowing.find({ userId, returnedDate: null });
    res.json(borrowings);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
