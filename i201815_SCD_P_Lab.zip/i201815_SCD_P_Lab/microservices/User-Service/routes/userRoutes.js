const express = require('express');
const userController = require('../controllers/userController');

const router = express.Router();

router.get('/users/:id', userController.getUserDetails);
router.post('/users', userController.registerUser);

module.exports = router;
