const express = require('express');
const mongoose = require('mongoose');

const app = express();
const port = 3004;

mongoose.connect('mongodb://localhost:27017/reviewdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(express.json());

// Review Model
const Review = mongoose.model('Review', {
  bookId: { type: String, required: true },
  userId: { type: String, required: true },
  rating: { type: Number, required: true, min: 1, max: 5 },
  comment: { type: String },
  createdAt: { type: Date, default: Date.now },
});

// Add a book review
app.post('/api/add-review', async (req, res) => {
  const { bookId, userId, rating, comment } = req.body;

  try {
    // Check if the book exists
    // You may want to perform additional validation or check with the book service
    // This example assumes the bookId is valid

    // Create a review record
    const newReview = new Review({ bookId, userId, rating, comment });
    await newReview.save();

    res.status(201).json(newReview);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get reviews for a book
app.get('/api/book-reviews/:bookId', async (req, res) => {
  const { bookId } = req.params;

  try {
    // Find all reviews for the specified book
    const reviews = await Review.find({ bookId });
    res.json(reviews);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
