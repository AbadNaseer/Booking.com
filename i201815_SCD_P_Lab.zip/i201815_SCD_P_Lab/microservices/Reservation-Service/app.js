const express = require('express');
const mongoose = require('mongoose');
const axios = require('axios');

const app = express();
const port = 3003;

mongoose.connect('mongodb://localhost:27017/reservationdb', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

app.use(express.json());

// Book service URL
const bookServiceUrl = 'http://localhost:3000/api/books';

// Reservation Model
const Reservation = mongoose.model('Reservation', {
  userId: { type: String, required: true },
  bookId: { type: String, required: true },
  reservedDate: { type: Date, default: Date.now },
  cancelledDate: { type: Date, default: null },
});

// Reserve a book
app.post('/api/reserve', async (req, res) => {
  const { userId, bookId } = req.body;

  try {
    // Check if the book exists
    const bookResponse = await axios.get(`${bookServiceUrl}/books/${bookId}`);
    if (bookResponse.status !== 200) {
      return res.status(bookResponse.status).json({ error: 'Book not found' });
    }

    // Check if the book is available
    if (!bookResponse.data.available) {
      return res.status(400).json({ error: 'Book not available for reservation' });
    }

    // Create a reservation record
    const newReservation = new Reservation({ userId, bookId });
    await newReservation.save();

    // Update book availability
    await axios.put(`${bookServiceUrl}/books/${bookId}`, { available: false });

    res.status(201).json(newReservation);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Cancel a book reservation
app.post('/api/cancel-reservation', async (req, res) => {
  const { userId, bookId } = req.body;

  try {
    // Find the reservation record
    const reservation = await Reservation.findOne({ userId, bookId, cancelledDate: null });
    if (!reservation) {
      return res.status(404).json({ error: 'Reservation not found' });
    }

    // Update reservation record with cancellation date
    reservation.cancelledDate = Date.now();
    await reservation.save();

    // Update book availability
    await axios.put(`${bookServiceUrl}/books/${bookId}`, { available: true });

    res.json(reservation);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

// Get user's reserved books
app.get('/api/reserved-books/:userId', async (req, res) => {
  const { userId } = req.params;

  try {
    // Find all reservation records for the user
    const reservations = await Reservation.find({ userId, cancelledDate: null });
    res.json(reservations);
  } catch (error) {
    console.error(error);
    res.status(500).json({ error: 'Internal Server Error' });
  }
});

app.listen(port, () => {
  console.log(`Server is running on port ${port}`);
});
